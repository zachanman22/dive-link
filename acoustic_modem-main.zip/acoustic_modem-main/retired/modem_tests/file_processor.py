from tkinter.filedialog import askopenfilename

#

filename = askopenfilename()

print(filename)
