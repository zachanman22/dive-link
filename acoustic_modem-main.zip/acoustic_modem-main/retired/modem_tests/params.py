params = {
    "bytes": [1024, 300, 150, 75],
    "channels": [x for x in range(8)],
    "volume": [x/10 for x in range(10, 0, -1)],
    "baud": [2000, 1000, 500]
}
