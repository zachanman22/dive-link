import time

if __name__ == '__main__':
    while True:
        print(time.time())
        time.sleep(0.1)