message = "hello how are you today"
ssc = message.encode('utf-8').encode('zlib')